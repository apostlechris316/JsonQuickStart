using JsonQuickStart;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.IO;

namespace TestJsonQuickStart
{
    [TestClass]
    public class TestJsonFileSystemManager
    {
        [TestMethod]
        public void Test_001_001_SimpleStringSave()
        {
            string testString = "test";
            var dataSource = "C:\\_unit_test\\Data\\JsonQuickStart\\TestSimpleStringSave";

            // Ensure we are starting from empty directory
            if (System.IO.File.Exists(dataSource) == true)
            {
                Directory.Delete(dataSource);
            }

            // Write the string to the data source
            var jsonFileSystemManager = new JsonFileSystemManager();
            Assert.IsTrue(jsonFileSystemManager.InsertItem(dataSource, testString, "string", typeof(string), testString, testString));

            // Read the items back
            var jsonFileItems = jsonFileSystemManager.LoadAllJsonFileItems(dataSource, "string");

            // Validate results
            Assert.IsNotNull(jsonFileItems);
            Assert.AreEqual(1, jsonFileItems.Count);
        }

        [TestMethod]
        public void Test_001_002_MultipleStringSave()
        {
            string testString1 = "test1";
            string testString2 = "test2";
            string testString3 = "test3";
            string testString4 = "test4";
            string testString5 = "test5";

            var dataSource = "C:\\_unit_test\\Data\\JsonQuickStart\\TestMultipleStringSave";

            // Ensure we are starting from empty directory
            if (System.IO.File.Exists(dataSource) == true)
            {
                Directory.Delete(dataSource);
            }

            // Write the strings to the data source
            var jsonFileSystemManager = new JsonFileSystemManager();

            // Read the items first
            var jsonFileItems = jsonFileSystemManager.LoadAllJsonFileItems(dataSource, "string");

            // Ensure we get no items back
            Assert.IsNotNull(jsonFileItems);
            Assert.AreEqual(0, jsonFileItems.Count);

            // Add the 5 test items
            jsonFileItems.Add(jsonFileSystemManager.GetJsonItemFileForItem(testString1, Guid.NewGuid().ToString(), typeof(string)));
            jsonFileItems.Add(jsonFileSystemManager.GetJsonItemFileForItem(testString2, Guid.NewGuid().ToString(), typeof(string)));
            jsonFileItems.Add(jsonFileSystemManager.GetJsonItemFileForItem(testString3, Guid.NewGuid().ToString(), typeof(string)));
            jsonFileItems.Add(jsonFileSystemManager.GetJsonItemFileForItem(testString4, Guid.NewGuid().ToString(), typeof(string)));
            jsonFileItems.Add(jsonFileSystemManager.GetJsonItemFileForItem(testString5, Guid.NewGuid().ToString(), typeof(string)));

            Assert.IsTrue(jsonFileSystemManager.InsertItems(dataSource, jsonFileItems, "string", typeof(string)));

            // Read the items back
            jsonFileItems = jsonFileSystemManager.LoadAllJsonFileItems(dataSource, "string");

            // Validate results
            Assert.IsNotNull(jsonFileItems);
            Assert.AreEqual(5, jsonFileItems.Count);
        }
    }
}
